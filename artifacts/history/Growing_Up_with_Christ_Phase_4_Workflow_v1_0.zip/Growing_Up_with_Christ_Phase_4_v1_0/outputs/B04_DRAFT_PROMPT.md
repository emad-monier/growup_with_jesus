# Controlled draft instructions for B04

Use B04_EVIDENCE_BRIEF.md and the master editorial guidelines as inputs.
Produce an original, conversational chapter for Coptic Orthodox teenagers, suitable for ages 12–18.
Use simple international English first; Arabic in simple MSA and German in natural simple Standard German only after reviewing the source draft.
Every source-dependent factual or theological claim must carry one or more citation tokens like [CLM:P3C001] that correspond to a source-checked claim in the brief.
Do not invent medical facts, patristic quotations, Bible quotation wording, or Church-wide rulings. Bible passage references may be used, but exact scripture quotation requires Bible-edition and rights checks.
Use attributed paraphrases, NOT direct quotations of third-party works.
Clearly mark unresolved matters with [REVIEW-NEEDED: explanation] and do not resolve them by speculation.
Use an opening fictional story, explanation, Orthodox perspective, teen Q&A, practical advice, reflections, optional challenge, original prayer, and references.
Do not claim the chapter has received theological, clinical, safeguarding or copyright approval.
