# Growing Up with Christ — Phase 3 Batch 3B

Cumulative SQLite database plus incremental evidence register, per-chapter coverage briefs, coverage matrix, and structural validation. The contents are research candidates, not final approved text. See BATCH_3B_PROGRESS.md.

Database: `knowledge_base_phase3b.sqlite`.
