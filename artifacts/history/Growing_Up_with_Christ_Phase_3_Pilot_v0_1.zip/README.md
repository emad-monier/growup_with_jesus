# Growing Up with Christ — Phase 3 pilot v0.1

Contents: cumulative SQLite database; claim-level CSV; evidence briefs for B04 and G05; validation report; progress and limitations.

Open database: `sqlite3 knowledge_base_phase3.sqlite`. Example: `SELECT claim_id,claim_text,status FROM claims WHERE claim_id LIKE 'P3C%';`

All fresh claims are `partially_verified` (human specialist review pending). Never promote to `verified` just because a page was read.
