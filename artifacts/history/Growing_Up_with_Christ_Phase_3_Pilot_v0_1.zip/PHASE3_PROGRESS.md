# Phase 3 — Pilot knowledge extraction (v0.1)

This is **the first extraction batch**, not completion of Phase 3. Eleven original-language or English paraphrased claims are tied to six directly examined page sections. The source locator is section-level; paragraph-level offsets and printed pages are still pending.

## Evidence semantics
- `passages.read_status=checked`: an identified live source section was read.
- `evidence.review_status=reviewed`: assistant checked the paraphrase against that online section. It does **not** signify clerical or clinical endorsement.
- `claims.status=partially_verified`: content has source support, but expert review/currency checks remain open.
- `claims.status=verified`: **zero**, reserved for reviewed claims that passed appropriate human expertise.
- `chapter_claims.use_case=candidate`: not publication approved.

## Red flags
- Fr. Tadros's historic discussions include Freud-based stages; do not use these as medical/scientific authority.
- NHS period pages show review due Jan 2026. Recheck currency or prefer more recent clinical guidance before publication.
- No direct quotations are stored in this package. Source links allow later rights-compliant inspection.
- Liturgical questions about periods and Communion are not resolved in this batch.

## Next extraction
Confirm individual paragraphs/printed page numbers, gather contemporary specialist menstrual-health guidance, add church-reviewed pastoral treatment, and complete the lesson objective coverage checklist before drafting.
