# Growing Up with Christ

Coptic Orthodox growing-up guides for teenage boys and girls, planned in **English, German, and Arabic**.

## Project status

- Phases 0–3: baseline, sources and pilot evidence preparation completed with outstanding gaps tracked.
- Phase 4: command-line research brief and citation-ID validation prototype. **No LLM API is connected.**
- No chapters or source claims have received expert or publication approval.

## Start

Requires Python 3.10+ (standard library only):

```bash
cd writing_system
python workflow.py prepare B04
python workflow.py prepare G05
python -m unittest discover -p 'test_*.py'
```

The pilot database is stored in `knowledge_base/`. A copy of the pilot SQLite database is included in `writing_system/input/` to preserve the existing workflow paths. No external content or protected full books are included.

## Structure

- `docs/`: editorial guidelines, decisions, chapter outlines and roadmap
- `data/`: chapter and source registries
- `research/`: inventories, open gaps, source citations and permissions
- `knowledge_base/`: SQLite research database (pilot, not publication approved)
- `writing_system/`: prototype code and tests
- `examples/`: generated example briefs/templates

## Rules

Do not represent AI output as approved Church teaching. Verify source passages and professional evidence; obtain quotation permissions before publication. Keep personal data, credentials, and protected full texts outside this repository.
