# Growing Up with Christ — Phase 2 v0.7

Cumulative source collection through Batch 2F. SQLite holds 2F additions and prior 2A–2E data. See `PHASE2_BATCH2F_REPORT.md`, `PHASE2_COMPLETION_AUDIT.md`, `RIGHTS_AND_PERMISSIONS_REGISTER.csv`, and `LITURGY_SAINTS_RIGHTS_INVENTORY.csv`. **Phase 2 is still open.**
