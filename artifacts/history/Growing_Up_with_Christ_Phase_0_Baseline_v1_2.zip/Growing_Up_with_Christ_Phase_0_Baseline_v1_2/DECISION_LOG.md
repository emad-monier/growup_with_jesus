# Decision Log — Approved and Pending
| ID | Decision | Status | Notes |
|---|---|---|---|
| D01 | Two companion guides for boys and girls aged 12–18 | Agreed | 23 and 26 working chapters |
| D02 | Three full editions per guide: English, Arabic, German | Agreed | Six total |
| D03 | Style: warm, clear, biblical, pastoral, Pope Shenouda III-inspired general qualities | Agreed | Original text; no impersonation |
| D04 | Arabic: الفصحى المبسطة | Agreed | Natural Fusha, not colloquial |
| D05 | English: simple international English | Agreed | No regional slang dependence |
| D06 | German: einfaches natürliches Hochdeutsch | Agreed | *du*; not Leichte Sprache |
| D07 | Bible Arabic: Smith–Van Dyke | Agreed | Rights check |
| D08 | Bible English: NKJV | Agreed | Rights check |
| D09 | Bible German: Einheitsübersetzung 2016 | Provisional | Coptic pastoral consultation + rights check |
| D10 | Prefer Arabic Coptic authors and authenticated Fathers | Agreed | Pope Shenouda III, Bishop Moussa, Fr Tadros Malaty |
| D11 | Separate medical and psychological evidence from theological tradition | Agreed | Clinical safeguards required |
| D12 | Graph+passage retrieval knowledge base for writing | Agreed in principle | Lightweight SQLite first |
| D13 | Publish six complete reviewed manuscripts, not abbreviated versions | Agreed | Word/PDF/EPUB targets |
| D14 | Source texts may be reproduced/translated based on online presence alone | Rejected | Permissions required |
