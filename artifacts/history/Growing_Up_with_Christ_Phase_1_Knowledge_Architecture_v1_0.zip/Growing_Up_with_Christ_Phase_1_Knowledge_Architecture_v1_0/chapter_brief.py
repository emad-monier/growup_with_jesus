#!/usr/bin/env python3
import sqlite3, argparse, pathlib
p=argparse.ArgumentParser(description='Inspect source candidates and evidence readiness; does not generate unsupported claims')
p.add_argument('chapter',help='B01–B23 or G01–G26'); p.add_argument('--db',default=str(pathlib.Path(__file__).resolve().parent/'data'/'knowledge_base.sqlite'))
a=p.parse_args();db=sqlite3.connect(a.db);db.row_factory=sqlite3.Row
r=db.execute('SELECT * FROM chapters WHERE chapter_id=?',(a.chapter,)).fetchone()
if r is None:raise SystemExit('Unknown chapter ID')
print(f"{r['chapter_id']}: {r['title']}\n")
for s in db.execute('SELECT s.source_id,w.title,s.url,cs.relationship FROM chapter_sources cs JOIN sources s USING(source_id) JOIN works w USING(work_id) WHERE cs.chapter_id=? ORDER BY s.source_id',(a.chapter,)):
 print(f"- {s['source_id']} [{s['relationship']}] {s['title']}\n  {s['url']}")
ready=db.execute('SELECT * FROM chapter_evidence_readiness WHERE chapter_id=?',(a.chapter,)).fetchone()
print(f"\nSource candidates: {ready['candidate_sources']}; mapped claims: {ready['mapped_claims']}; verified claims: {ready['verified_claims']}")
print('STATUS: RESEARCH ONLY — not evidence-ready' if ready['verified_claims']==0 else 'STATUS: PARTIAL EVIDENCE — specialist review may still be needed')
