# Phase 2 Batch 2F — Liturgical sources, saints, and permissions

## Scope
Indexed the Agpeya, Coptic Synaxarium entries for St Demiana and St Marina, a Psalm-numbering aid, and documented rights notices. The Synaxarium is an ecclesial hagiographic source, not independent historical verification. A German Catholic licensing source is used **only** as a rights comparison, never as an official Coptic source.

## Source quality
Eleven source-location/rights leads were entered based on externally discoverable webpage evidence. **These are not fully transcribed, authenticated editions, or verified theological claims.** No copyrighted full texts were copied. The Divine Liturgy and Kholagy primary Coptic text edition, full Arabic Agpeya text edition, St Verena life, and multiple saints' precise histories remain **unverified or uncollected**.

## Permissions findings
- NKJV has conditional quotation permission, subject to limits and attribution; determine whether these books qualify (religious reference/book commentary exclusion requires attention).
- German Einheitsübersetzung copying normally requires rights-holder approval when not covered by legal quotation exceptions; do not infer free use.
- Historical Smith–Van Dyck text is catalogued as public domain, but digital editions, typesetting, notes, and territories require separate evaluation.
- St-Takla/Coptic Treasures hosting permissions cannot be transferred to our publication.
- Traditional prayers may be old, while edited translations, liturgical book editions and arrangements may be protected.

## Phase 2 audit / unresolved blockers
1. Batch 2A complete subsection inventory missing; inaccessible chapter indexes must be recovered via an authorized copy or alternate index.
2. Batch 2B four books have only partial indexes/sections.
3. Batch 2C two works located only at catalogue level.
4. Batch 2D authenticated sayings and precise page/section references remain incomplete.
5. Batch 2E clinical claims and currency confirmations, including older menstrual guidance, remain open for Phase 3 and professional review.
6. Batch 2F need Coptic authorized Kholagy/liturgy editions, German Coptic text variants, Synaxarium edition metadata and St Verena primary account.
7. Rights-holder approvals have not been obtained, not even for Bible quotations.
8. The German Bible selection remains provisional pending Coptic priest consultation.

## Decision gate
**Batch 2F initial inventory complete; Phase 2 overall remains OPEN.** A pilot chapter can enter source extraction only after chapter-specific source coverage is checked; full book production cannot claim source readiness.
