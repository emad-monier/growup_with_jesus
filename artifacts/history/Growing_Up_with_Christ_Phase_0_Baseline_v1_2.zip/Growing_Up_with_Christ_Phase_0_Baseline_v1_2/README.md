# Growing Up with Christ — Phase 0 Baseline
Generated: 2026-10-17. This package consolidates the existing reference matrix v2, knowledge graph v0.1, decisions, and technical validation findings.

## Start here
1. `VALIDATION_REPORT.md` — quantitative audit and integrity checks.
2. `RESEARCH_GAPS.csv` — actionable open issues.
3. `DECISION_LOG.md` — agreed choices and provisional items.
4. `PROJECT_MASTER_PLAN.md` — next phases and acceptance gates.
5. `CHAPTER_REGISTRY.csv`, `SOURCE_REGISTRY.csv`, `MEDICAL_SOURCE_REGISTRY.csv` — normalized, UTF-8 CSV exports of original records.
6. `knowledge_graph_v0_1/` — preserved original graph and concept notes.
7. `inputs/` and `INPUT_MANIFEST.json` — original input workbooks and graph archive, with SHA-256 checksums.

## Honest completion state
**Phase 0 assembled/audited:** yes. **Full original editorial guidelines and chapter-outline source documents archived:** no — only chat text plus their structured chapter registry are available. **Full-text source verification:** not completed. **Medical / theological / rights review:** not completed.
