# B04 — Batch 3B evidence coverage

**New claims mapped:** 9
**Status:** evidence supported by checked public sections; independent expert approval outstanding.

## Development and variation — SOURCE-LOCATED; REVIEW PENDING
- **CLM-3B005:** Unplanned erections and nocturnal emissions can occur during male puberty without sexual intention and should not be a cause for blame. — https://www.healthychildren.org/English/ages-stages/gradeschool/puberty/pages/Concerns-Boys-Have-About-Puberty.aspx
- **CLM-3B006:** Voice changes and temporary cracking are normal features of male pubertal development. — https://www.healthychildren.org/English/ages-stages/gradeschool/puberty/pages/Concerns-Boys-Have-About-Puberty.aspx
- **CLM-3B007:** The timing of puberty varies; unusually early or delayed changes may warrant clinical assessment. — https://www.nhs.uk/conditions/early-or-delayed-puberty/

## Body dignity and emotions — SOURCE-LOCATED; REVIEW PENDING
- **CLM-3B001:** Fr. Tadros links respect for the human body with the Incarnation and argues that bodily life should be cared for rather than despised. — https://st-takla.org/books/fr-tadros-malaty/grow/care.html
- **CLM-3B002:** Fr. Tadros urges parents, schools, and Church mentors to discuss adolescent bodily changes in a supportive way rather than causing shame. — https://st-takla.org/books/fr-tadros-malaty/grow/care.html
- **CLM-3B003:** Bishop Moussa places sexuality in the theological context of love, communion, and marriage. — https://st-takla.org/Full-Free-Coptic-Books/FreeCopticBooks-009-Bishop-Moussa/002-Al-Shabab-Wa-Hayat-Al-Tahara/Youth-n-Purity-03-Why-God-Created-Sex.html

## Respect, consent, safety — SOURCE-LOCATED; REVIEW PENDING
- **CLM-3B013:** Age-appropriate educational material should accurately address bodily development, respect, consent, and knowing how to seek help. — https://www.who.int/news-room/fact-sheets/detail/comprehensive-sexuality-education
- **CLM-3B014:** Sexual activity involving a child who cannot give informed consent constitutes child sexual abuse, and children need safe avenues to report concerns. — https://www.cdc.gov/child-abuse-neglect/about/about-child-sexual-abuse.html

## Hygiene and health behaviours — GAP
- Requires new evidence / documented pastoral decision before chapter approval.

## When to obtain medical help — SOURCE-LOCATED; REVIEW PENDING
- **CLM-3B007:** The timing of puberty varies; unusually early or delayed changes may warrant clinical assessment. — https://www.nhs.uk/conditions/early-or-delayed-puberty/
