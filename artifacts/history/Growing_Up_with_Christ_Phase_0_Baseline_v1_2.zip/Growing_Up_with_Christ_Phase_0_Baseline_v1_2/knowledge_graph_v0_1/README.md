# Growing Up with Christ — Evidence-Labeled Knowledge Graph v0.1

## Honest scope
This is a **retrieval-ready reference graph and small verified-concept seed**, NOT a complete knowledge base extracted from all theology, medical, and patristic source texts. It is derived from the v2 workbook (49 chapters, 19 Orthodox reference entries, 16 professional-source entries) plus **four explicitly checked concept notes**. Source URLs in the workbook are described as verified pages, but not every original page or book was re-opened for this deliverable. Specific author passages, chapter claims and quotations generally remain unverified.

## Contents
- `nodes.jsonl`: node records (`chapter`, `orthodox_source`, `professional_source`, `bible_reference`, `concept`).
- `edges.jsonl`: typed chapter→reference connections, chapter→concept candidates, and verified concept→source connections.
- `knowledge_graph.sqlite`: portable SQL knowledge graph.
- `knowledge_graph.graphml`: GraphML graph for Gephi/yEd/NetworkX.
- `concept_cards.json`: paraphrased, explicitly source-linked starter knowledge cards (no copyrighted source text copied).

## Counts
- Nodes: 153
- Edges: 342
- By node type: {'orthodox_source': 19, 'professional_source': 16, 'chapter': 49, 'bible_reference': 65, 'concept': 4}
- By edge type: {'suggested_theological_source': 133, 'suggested_professional_source': 84, 'suggested_biblical_reference': 105, 'supported_by': 4, 'concept_candidate': 16}

## Sample SQL
```sql
SELECT n.label, e.relation, s.label, json_extract(s.properties_json,'$.url') AS url
FROM edges e JOIN nodes n ON e.source=n.id JOIN nodes s ON e.target=s.id
WHERE n.id='G05';
```

## Evidence safeguards
- `suggested_theological_source` = **bibliographic topic match**, not proof of a quoted claim.
- `suggested_professional_source` = **candidate source**, not verification of medical advice.
- `suggested_biblical_reference` = reference only; verify verses in NKJV, Einheitsübersetzung 2016, Van Dyke, plus Orthodox numbering/canon.
- `supported_by` attaches a **source-page checked concept** and contains an original paraphrase, never an invented quote.
- Store more granular evidence as concept cards with source URL, original section heading, exact location/page if available, type of claim, date accessed, editor and review status.

## Writing pipeline
1. Retrieve the chapter and its linked sources.
2. Read the actual relevant source passages, not just book titles.
3. Produce granular original paraphrase concept cards with exact links and validation status.
4. Separate Orthodox doctrine, pastoral opinion, historical tradition, scientific evidence, and current safeguarding instructions.
5. Construct an evidence brief for the chapter; do not write unsupported claims.
6. Draft English/Arabic in coordination; produce natural German adaptation.
7. Complete theological, clinical/safeguarding, translation and copyright reviews.

## Missing before publication
Full-text reading/extraction for selected Arabic source works and patristic primary texts; book edition/page anchors; source-per-claim science audit; latest version checks; quote licensing; native-language and professional review. A graph of *metadata alone* cannot answer these needs.
