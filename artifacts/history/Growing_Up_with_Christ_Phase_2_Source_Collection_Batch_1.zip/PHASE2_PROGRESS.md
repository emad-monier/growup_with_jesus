# Phase 2 — Source Collection (first batch, ongoing)

Status: **in progress, not complete**.

Completed in this batch:
- Checked source pages for Fr. Tadros, Pope Shenouda III, Bishop Moussa, NHS, WHO, and CDC.
- Registered 15 specific locations in a machine-readable manifest and SQLite discovery table.
- Preserved all Phase 1 chapters, source candidates, and verification gates.
- Recorded separate copyright/reuse restrictions.

Not done:
- No whole-book texts, PDF scans, or full web-page texts were copied locally.
- No passage is marked checked; no claim is newly verified. That belongs to Phase 3.
- Other planned literature, Church Fathers, liturgy, German-specific clinical sources and more medical guidelines require acquisition and checking.
- Direct permissions and final edition bibliographies are still outstanding.

Priority next collection: complete section inventory of `دعوني أنمو!`, sections of `حياة الإيمان` and `حياة التوبة والنقاوة`, specific passages of Bishop Moussa, then German AWMF and validated modern pediatric guidance on menstruation.

Publication gate: no quote/translation reuse until rights documented.
