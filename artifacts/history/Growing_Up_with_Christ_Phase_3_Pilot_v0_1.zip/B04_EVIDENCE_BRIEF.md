# Evidence brief — B04

Status: SOURCE-LOCATED AND PASSAGE-CHECKED; NOT CLINICALLY OR THEOLOGICALLY APPROVED.

Source quotes are intentionally not stored. This brief provides original paraphrases and exact source-section references.

## P3C001 — pastoral
Fr. Tadros describes the human body as worthy of care and respect rather than contempt.

- Source: أرع جسدك ولا تؤلهه!, 2 and 4
- URL: https://st-takla.org/books/fr-tadros-malaty/grow/care.html
- Status: partially_verified
- Caveat: Source reviewed; theological interpretation requires clerical review. Exact online section checked, but independent human approval not completed.

## P3C002 — pastoral
Fr. Tadros encourages adults to respond supportively to adolescents experiencing physical changes and new feelings.

- Source: أرع جسدك ولا تؤلهه!, 2 and 4
- URL: https://st-takla.org/books/fr-tadros-malaty/grow/care.html
- Status: partially_verified
- Caveat: Source reviewed; pastoral advice, not a clinical claim. Exact online section checked, but independent human approval not completed.

## P3C003 — pastoral
Fr. Tadros rejects treating sexual development as inherently impure or shameful.

- Source: الغريزة الجنسية في حياة المؤمن, opening and final paragraphs
- URL: https://st-takla.org/books/fr-tadros-malaty/grow/instinct.html
- Status: partially_verified
- Caveat: Source reviewed; do not reuse historical Freudian model as science. Exact online section checked, but independent human approval not completed.

## P3C004 — medical
Puberty involves changes such as underarm and pubic hair, genital growth and voice changes in boys, and breast development and menstruation in girls.

- Source: Early or delayed puberty, Symptoms of early or delayed puberty; Non-urgent advice
- URL: https://www.nhs.uk/conditions/early-or-delayed-puberty/
- Status: partially_verified
- Caveat: NHS general educational guidance; clinical review remains pending. Exact online section checked, but independent human approval not completed.

## P3C005 — medical
Puberty timing varies, and medical advice is appropriate if development appears unusually early or delayed.

- Source: Early or delayed puberty, Symptoms of early or delayed puberty; Non-urgent advice
- URL: https://www.nhs.uk/conditions/early-or-delayed-puberty/
- Status: partially_verified
- Caveat: Do not use one age cutoff to diagnose an individual; clinical review pending. Exact online section checked, but independent human approval not completed.

## P3C006 — medical
Menstruation is a natural part of puberty; preparing young people to understand periods helps remove embarrassment.

- Source: Starting your periods, Talking about periods; The questions girls ask about periods
- URL: https://www.nhs.uk/conditions/periods/starting-periods/
- Status: partially_verified
- Caveat: NHS 2023 reviewed page past scheduled review; needs currency check. Exact online section checked, but independent human approval not completed.

## P3C011 — safeguarding
Age-appropriate health education can cover puberty, menstruation, body image, privacy, consent, and seeking support.

- Source: Comprehensive sexuality education, Key facts; What CSE covers
- URL: https://www.who.int/news-room/fact-sheets/detail/comprehensive-sexuality-education
- Status: partially_verified
- Caveat: WHO educational framework; editorial selection aligned with values requires further review. Exact online section checked, but independent human approval not completed.
