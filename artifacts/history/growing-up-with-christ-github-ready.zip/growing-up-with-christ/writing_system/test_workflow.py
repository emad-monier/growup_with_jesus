import unittest,tempfile,pathlib
import workflow
class Tests(unittest.TestCase):
 def test_both(self):
  for cid in ('B04','G05'):
   b=workflow.brief(cid)
   self.assertTrue(b['grounded_claims'])
   self.assertTrue(all(x['evidence'] for x in b['grounded_claims']))
 def test_invalid_id_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'bad.md';p.write_text('## Understanding the topic\n[CLM:FAKE]\n## What our Church teaches\n## Practical advice')
   r=workflow.check('B04',p);self.assertFalse(r['checks_passed']);self.assertIn('FAKE',r['invalid_citations'])
 def test_valid_marker_passes_syntax_not_approval(self):
  cid='B04';marker=workflow.brief(cid)['grounded_claims'][0]['id']
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'example.md';p.write_text('## Understanding the topic\n## What our Church teaches\n## Practical advice\n[CLM:'+marker+']')
   r=workflow.check(cid,p);self.assertTrue(r['checks_passed']);self.assertFalse(r['publication_approved'])
if __name__=='__main__':unittest.main()
