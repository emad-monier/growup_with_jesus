# Phase 1 — Knowledge architecture and gates

## Data model
Authors → works → editions/sources → anchored passages → evidence → claims → concepts → chapters. Independent review and translation records are explicit. Chapter-to-source links imported from Phase 0 are **research candidates**, never evidence.

## Evidence gate
Claim status `verified` alone is insufficient: `verified_claims` requires a supporting evidence record marked `reviewed` and a source passage marked `checked`. Clinical and theological sign-off are separate review stages. Claims may be supported, contradicted, or contextualized.

## Provenance and rights
Maintain a stable source ID and original URL; add edition ID, section/page anchor, content checksum, acquisition method, rights status, reviewed source wording, and reviewer credentials later. No source content was mass-collected here.

## Phase 1 acceptance
- All 49 chapters retained with IDs.
- All 35 sources retained; link status remains bibliographic, not evidence-grade.
- Foreign keys and fail-closed checks pass.
- CLI exposes candidate references without inventing an evidence brief.

## Still needed in Phases 2–4
1. Acquire permitted passages, record exact edition and locators.
2. Verify extracts and link claim-level evidence.
3. Implement content search / multilingual embeddings and citation check.
4. Complete human theological, clinical, language and safeguarding reviews before publication.

## Phase 0 issues
ISS-007, ISS-008 remain resolved. Other ten Phase 0 issues remain open; Phase 1 does not silently close them.
