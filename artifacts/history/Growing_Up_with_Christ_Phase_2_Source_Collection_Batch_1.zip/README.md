# Growing Up with Christ — Phase 2 Collection Batch 1

Start here: `PHASE2_PROGRESS.md` and `SOURCE_COLLECTION_MANIFEST.csv`.

`knowledge_base_phase2.sqlite` extends the Phase 1 SQLite database with `phase2_source_discovery`; it does not falsely upgrade candidate sources to verified evidence.

Recreate inspections against recorded URLs before writing; web content can change.
