# Growing Up with Christ — Phase 1 Knowledge Architecture v1.0

This is a **runnable, evidence-fail-closed prototype**, not a verified corpus. It imports the Phase 0 chapter/source registry without treating research mappings as claim support.

## Files
- `data/knowledge_base.sqlite`: relational evidence graph
- `docs/schema.sql`: portable SQLite schema
- `docs/SCHEMA_AND_GATES.md`: semantics and gates
- `docs/VALIDATION_REPORT.json`: migration results
- `chapter_brief.py`: chapter research candidates and readiness

## Test
`python chapter_brief.py B04` or `python chapter_brief.py G05`

## Warning
No passages were extracted or approved in Phase 1; existing concept cards remain unverified. Do not use the database as a sole factual or theological source for manuscripts.
