# Editorial Guidelines — Controlled Phase 0 Summary
This file is a **summary of the approved chat-level Master Editorial Guidelines v1.0**, not a verbatim copy. Full signed-off text must be transferred into the repository before Phase 1.

## Identity and tone
Coptic Orthodox; 12–18; independent private reading; warm direct pastoral voice inspired by Pope Shenouda III's general approachable qualities. Original writing only; no fake quotes.

## Language and Bible
English simple international, NKJV. Arabic الفصحى المبسطة, Smith–Van Dyke. German natural easy Standard German (*du*), Einheitsübersetzung 2016 provisional.

## Source authority
Scripture and Church doctrine/liturgy; Arabic Orthodox authors and authenticated Church Fathers; independent clinical/professional sources for health and safeguarding.

## Editorial constraints
Distinguish doctrine/pastoral guidance/cultural customs, biological facts/spiritual teaching, historical tradition/independently documented history; reference all source-dependent claims; check licensing.

## Safety
Accurate, non-shaming puberty/menstruation/sexuality information, explicit consent and abuse-safety guidance, no victim blame; spiritual support does not replace medical or psychological care.

## Reviews
Editorial, qualified Orthodox theology, relevant clinician, safeguarding, native-language, rights, final publication sign-off. AI checks are supplementary only.
