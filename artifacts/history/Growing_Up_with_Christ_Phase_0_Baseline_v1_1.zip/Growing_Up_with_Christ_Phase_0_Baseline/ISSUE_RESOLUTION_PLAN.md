# Open Issues — Phase Assignment and Acceptance Gates

This ledger is an implementation control. All findings remain **OPEN** until independently checked and closure evidence is recorded.

| ID | Severity | Assigned phase(s) | Issue | Closure evidence | Status |
|---|---|---|---|---|---|
| ISS-001 | high | 2–3 | SOURCE_FULLTEXT | Each used claim links to exact source passage and edition; no unsupported claims in accepted chapters. | OPEN |
| ISS-002 | high | 2–3, 5–8 | MEDICAL_CLAIMS | All medical statements in each chapter checked against current professional evidence, specialist review recorded. | OPEN |
| ISS-003 | high | 2–3 | FATHERS_QUOTATIONS | All direct patristic quotations traced to primary work and suitable translation; uncertain sayings excluded or marked. | OPEN |
| ISS-004 | high | 1–2, 9 | RIGHTS | Permission status recorded for every reused text/image; required licenses obtained before publishing. | OPEN |
| ISS-005 | medium | 1, 7–8 | GERMAN_BIBLE | Qualified German-speaking Coptic pastoral reviewer confirms Bible choice or approves documented replacement. | OPEN |
| ISS-006 | high | 5, 8 | HUMAN_REVIEW | Signed theological, clinical (where applicable), safeguarding, and language reviews for every edition. | OPEN |
| ISS-007 | medium | Before Phase 1 | GUIDELINES_FILE | Full editorial guidelines captured in controlled file and cross-checked against approved chat text. | OPEN |
| ISS-008 | medium | Before Phase 1 | OUTLINES_FILE | Complete original outlines archived in controlled files and reconciled with chapter registry. | OPEN |
| ISS-009 | medium | Phase 2 | SOURCE_URL_LIVE | Every cited URL checked, publisher/version metadata confirmed and archived access date recorded. | OPEN |
| ISS-010 | high | Phase 3 | CONCEPT_DEPTH | Evidence coverage audit passes for each chapter learning objective, not merely graph node count. | OPEN |
| ISS-011 | medium | 1, 5–8 | AGE_DISAGGREGATION | Chapter guidance tagged for maturity/age bands; age-appropriate pilot feedback recorded. | OPEN |
| ISS-012 | medium | 2, before G05 draft | MEDICAL_GUIDELINE_AGE | Current menstruation guidance located and evaluated; 2015 ACOG item retained only with context if superseded. | OPEN |

## Execution rules
- **Before Phase 1:** close ISS-007 and ISS-008 or record a formally accepted deviation; the current chat is the canonical content until correctly archived.
- **At every phase gate:** inspect this ledger, update each issue’s status and attach a path to the evidence of closure.
- **Before pilot drafting:** resolve sources and age-specific issues relevant to that pilot, including ISS-012 for girls’ menstruation chapter.
- **Before any publication:** ISS-004 and ISS-006 must be fully closed, with the German Bible decision (ISS-005) explicitly resolved.
- **No automatic closure:** successful structural graph checks do not close content-verification items.
