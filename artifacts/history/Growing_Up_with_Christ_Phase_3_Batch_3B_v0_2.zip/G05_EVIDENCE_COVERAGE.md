# G05 — Batch 3B evidence coverage

**New claims mapped:** 11
**Status:** evidence supported by checked public sections; independent expert approval outstanding.

## Menstruation onset and variability — SOURCE-LOCATED; REVIEW PENDING
- **CLM-3B008:** First periods begin at different ages, with NHS reporting an average around age 12. — https://www.nhs.uk/conditions/periods/starting-periods/
- **CLM-3B009:** Girls who have not started menstruating by age 15 should seek medical assessment; earlier assessment is advised with absent puberty signs. — https://www.nhs.uk/conditions/periods/starting-periods/
- **CLM-3B012:** Irregular menstrual cycles can occur during puberty, but persistent or troubling irregularity can merit clinical assessment. — https://www.nhs.uk/symptoms/irregular-periods/

## Pain and bleeding red flags — SOURCE-LOCATED; REVIEW PENDING
- **CLM-3B010:** Heavy periods can include needing to change pads or tampons every one to two hours, bleeding longer than seven days, or interference with activities. — https://www.nhs.uk/conditions/heavy-periods/
- **CLM-3B011:** Period pain that prevents usual daily activities warrants medical attention. — https://www.nhs.uk/symptoms/period-pain/

## Products and practical hygiene — GAP
- Requires new evidence / documented pastoral decision before chapter approval.

## Bodily dignity and compassionate pastoral framing — SOURCE-LOCATED; REVIEW PENDING
- **CLM-3B001:** Fr. Tadros links respect for the human body with the Incarnation and argues that bodily life should be cared for rather than despised. — https://st-takla.org/books/fr-tadros-malaty/grow/care.html
- **CLM-3B002:** Fr. Tadros urges parents, schools, and Church mentors to discuss adolescent bodily changes in a supportive way rather than causing shame. — https://st-takla.org/books/fr-tadros-malaty/grow/care.html

## Church participation during menstruation — GAP
- Requires new evidence / documented pastoral decision before chapter approval.

## Respect, consent and safety — SOURCE-LOCATED; REVIEW PENDING
- **CLM-3B013:** Age-appropriate educational material should accurately address bodily development, respect, consent, and knowing how to seek help. — https://www.who.int/news-room/fact-sheets/detail/comprehensive-sexuality-education
- **CLM-3B014:** Sexual activity involving a child who cannot give informed consent constitutes child sexual abuse, and children need safe avenues to report concerns. — https://www.cdc.gov/child-abuse-neglect/about/about-child-sexual-abuse.html
