#!/usr/bin/env python3
"""Phase 4 evidence-first drafting helper. Stdlib-only; no AI service is invoked."""
import argparse, json, re, sqlite3, pathlib, datetime
ROOT=pathlib.Path(__file__).resolve().parent
DB=ROOT/'input'/'knowledge_base_phase3c.sqlite'
OUT=ROOT/'outputs'
OUT.mkdir(exist_ok=True)
RESTRICTED=['communion','menstruat','eucharist','التناول','الدورة الشهرية']

def connection():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c

def brief(ch):
 with connection() as c:
  chapter=c.execute('select * from chapters where chapter_id=?',(ch,)).fetchone()
  if chapter is None: raise SystemExit('Unknown chapter ID: '+ch)
  rows=c.execute('''SELECT cl.claim_id,cl.claim_text,cl.classification,cl.status as claim_status,
       e.review_status as evidence_status, e.relation, p.passage_id,p.section_title,p.locator,p.source_url,
       p.read_status, p.original_text,e.quote_permission_status
       FROM chapter_claims cc JOIN claims cl ON cc.claim_id=cl.claim_id
       LEFT JOIN evidence e ON e.claim_id=cl.claim_id
       LEFT JOIN passages p ON p.passage_id=e.passage_id
       WHERE cc.chapter_id=? ORDER BY cl.claim_id,p.passage_id''',(ch,)).fetchall()
  grouped={}
  for r in rows:
   r=dict(r);claim=r['claim_id'];item=grouped.setdefault(claim,{'id':claim,'text':r['claim_text'],'classification':r['classification'],'status':r['claim_status'],'evidence':[]})
   if r['passage_id']:
    item['evidence'].append({k:r[k] for k in ('passage_id','section_title','locator','source_url','read_status','evidence_status','relation','quote_permission_status')})
  claims=list(grouped.values())
  grounded=[x for x in claims if any(e['relation']=='supports' and e['read_status']=='checked' and e['evidence_status']=='reviewed' and e['source_url'] for e in x['evidence']) and x['status']!='unverified']
  lead=[x for x in claims if x not in grounded]
  coverage_file=ROOT/'input'/'COVERAGE_MATRIX_3C.csv'
  import csv
  with coverage_file.open(encoding='utf-8-sig',newline='') as f: coverage=[row for row in csv.DictReader(f) if ch in str(row)]
  payload={'chapter':dict(chapter),'evidence_class':'source_checked_not_expert_approved','grounded_claims':grounded,'research_leads':lead,'coverage':coverage,'editorial_warnings':['No specialist review has been recorded for these pilot chapters.','No direct source quotation permitted without separate rights review.']}
  if ch=='G05': payload['editorial_warnings'].append('Menstruation and Communion: present only as a documented attributed pastoral position; universal/current practice requires qualified clergy review.')
  return payload

def export(ch):
 b=brief(ch); p=OUT/f'{ch}_EVIDENCE_BRIEF.json';p.write_text(json.dumps(b,ensure_ascii=False,indent=2),encoding='utf-8')
 lines=[f"# {ch} — {b['chapter']['title']}",'> RESEARCH BRIEF — not approved for publication','',f"Source-checked claims: {len(b['grounded_claims'])}; ungrounded leads: {len(b['research_leads'])}",'', '## Claim evidence']
 for x in b['grounded_claims']:
  lines+=['',f"### [{x['id']}] {x['classification']}",x['text']]
  for e in x['evidence']:
   lines += [f"- {e['section_title']} — {e['locator']}; {e['source_url']} (source review: {e['evidence_status']})"]
 lines+=['','## Unverified leads — DO NOT cite as evidence']
 lines += [f"- {x['id']}: {x['text']}" for x in b['research_leads']]
 lines+=['','## Coverage records']+[f'- {json.dumps(row,ensure_ascii=False)}' for row in b['coverage']]
 lines+=['','## Editorial holds']+[f'- {w}' for w in b['editorial_warnings']]
 (OUT/f'{ch}_EVIDENCE_BRIEF.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 prompt=f'''# Controlled draft instructions for {ch}\n\nUse {ch}_EVIDENCE_BRIEF.md and the master editorial guidelines as inputs.\nProduce an original, conversational chapter for Coptic Orthodox teenagers, suitable for ages 12–18.\nUse simple international English first; Arabic in simple MSA and German in natural simple Standard German only after reviewing the source draft.\nEvery source-dependent factual or theological claim must carry one or more citation tokens like [CLM:P3C001] that correspond to a source-checked claim in the brief.\nDo not invent medical facts, patristic quotations, Bible quotation wording, or Church-wide rulings. Bible passage references may be used, but exact scripture quotation requires Bible-edition and rights checks.\nUse attributed paraphrases, NOT direct quotations of third-party works.\nClearly mark unresolved matters with [REVIEW-NEEDED: explanation] and do not resolve them by speculation.\nUse an opening fictional story, explanation, Orthodox perspective, teen Q&A, practical advice, reflections, optional challenge, original prayer, and references.\nDo not claim the chapter has received theological, clinical, safeguarding or copyright approval.\n'''
 (OUT/f'{ch}_DRAFT_PROMPT.md').write_text(prompt,encoding='utf-8')
 draft=f'# {b["chapter"]["title"]}\n\n> DRAFT TEMPLATE ONLY — NO BOOK CHAPTER HAS BEEN GENERATED\n\n## Opening story\n\n[Write an original fictional example.]\n\n## Understanding the topic\n\n[Write evidence-grounded explanation with [CLM:...] citations.]\n\n## What our Church teaches\n\n[Use attributed source-grounded paraphrases; mark unresolved issues.]\n\n## Questions teenagers ask\n\n[Write short clear answers supported by evidence.]\n\n## Practical advice\n\n[Use supported recommendations.]\n\n## Reflection and challenge\n\n[Age-appropriate, safe, optional.]\n\n## Original closing prayer\n\n[Original prayer, not falsely attributed.]\n\n## Source notes\n\n[Generate from reviewed claim IDs.]\n'
 (OUT/f'{ch}_DRAFT_TEMPLATE.md').write_text(draft,encoding='utf-8')
 return {'chapter':ch,'grounded':len(b['grounded_claims']),'leads':len(b['research_leads']),'output_dir':str(OUT)}

def check(ch, file):
 text=file.read_text(encoding='utf-8'); b=brief(ch)
 permitted={x['id'] for x in b['grounded_claims']}
 tags=re.findall(r'\[CLM:([^\]]+)\]',text)
 invalid=sorted(set(tags)-permitted)
 missing=not tags
 holds=re.findall(r'\[REVIEW-NEEDED:[^\]]+\]',text)
 structurals=[header for header in ['## Understanding the topic','## What our Church teaches','## Practical advice'] if header.lower() not in text.lower()]
 no_rights=re.search(r'\b(?:NKJV|Einheitsübersetzung|Van Dyke)\b',text,re.I) is not None
 report={'chapter':ch,'file':str(file),'citation_tokens':len(tags),'invalid_citations':invalid,'no_citations':missing,'missing_sections':structurals,'explicit_review_holds':len(holds),'translation_or_rights_caution':bool(no_rights),'checks_passed':not bool(invalid or missing or structurals),'publication_approved':False,'note':'Mechanical citation presence cannot verify prose entailment. Human source, theological, clinical and safeguarding review required.'}
 path=OUT/(ch+'_DRAFT_CHECK.json');path.write_text(json.dumps(report,indent=2),encoding='utf-8');return report

def main():
 ap=argparse.ArgumentParser(description=__doc__);sp=ap.add_subparsers(dest='cmd',required=True)
 e=sp.add_parser('prepare');e.add_argument('chapter_id',choices=['B04','G05'])
 v=sp.add_parser('check');v.add_argument('chapter_id',choices=['B04','G05']);v.add_argument('draft',type=pathlib.Path)
 a=ap.parse_args();print(json.dumps(export(a.chapter_id) if a.cmd=='prepare' else check(a.chapter_id,a.draft),indent=2,ensure_ascii=False))
if __name__=='__main__':main()
