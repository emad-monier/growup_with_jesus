# Growing Up with Christ — Phase 2 source collection v0.5

Preserves v0.4 and adds Batch 2D patristic inventory. See PATRISTIC_SOURCE_INVENTORY.csv, PHASE2_BATCH2D_REPORT.md and knowledge_base_phase2.sqlite. Entries are *locations*, not verified doctrinal claim evidence.
